# ForecastsController handles the main weather forecasting functionality
# This controller manages address input, geocoding, weather data retrieval, and caching
class ForecastsController < ApplicationController

  # Main action that displays the weather forecast form and results
  # Handles both GET requests (form display) and GET requests with address parameter (weather lookup)
  def show
    # Set default address for demonstration purposes
    @address_default = "1 Infinite Loop, Cupertino, California"
    
    # Store the address in session for persistence across requests
    session[:address] = params[:address]
    
    # Only process weather lookup if an address is provided
    if params[:address].present?
      begin
        # Clean and validate the input address
        @address = params[:address].strip
        
        # Validate address input - ensure it's at least 3 characters
        if @address.length < 3
          flash.alert = "Please enter a valid address (at least 3 characters)"
          return
        end
        
        # Step 1: Convert address to coordinates using geocoding service
        # This service handles API calls to Nominatim (OpenStreetMap) or falls back to mock data
        @geocode = GeocodeService.call(@address)
        
        # Step 2: Create cache key based on postal code and country
        # This ensures caching works at the postal code level as required
        @weather_cache_key = "#{@geocode.country_code}/#{@geocode.postal_code}"
        
        # Check if weather data already exists in cache
        @weather_cache_exist = Rails.cache.exist?(@weather_cache_key)
        
        # Step 3: Fetch weather data with 30-minute caching
        # Uses Rails.cache.fetch with expiration to implement the required caching behavior
        @weather = Rails.cache.fetch(@weather_cache_key, expires_in: 30.minutes) do
          # This block only executes if data is not in cache
          WeatherService.call(@geocode.latitude, @geocode.longitude)          
        end
        
        # Provide user feedback about cache status
        if @weather_cache_exist
          flash.notice = "Weather data retrieved from cache (cached for 30 minutes)"
        else
          flash.notice = "Weather data fetched successfully"
        end
        
      rescue IOError => e
        # Handle specific geocoding or weather API errors
        flash.alert = "Error: #{e.message}"
        Rails.logger.error "Forecast error: #{e.message}"
      rescue => e
        # Handle any unexpected errors gracefully
        flash.alert = "An unexpected error occurred. Please try again."
        Rails.logger.error "Unexpected forecast error: #{e.message}"
      end
    end
  end

end
