# WeatherService handles weather data retrieval from OpenWeatherMap API
# This service integrates with the OpenWeatherMap API and provides fallback mock data
# for demonstration purposes when API keys are not configured
class WeatherService
    
  # Main method to retrieve weather data for given coordinates
  # @param latitude [Float] The latitude coordinate
  # @param longitude [Float] The longitude coordinate
  # @return [OpenStruct] Object containing temperature, humidity, pressure, and description
  # @raise [IOError] If weather API fails and no fallback is available
  def self.call(latitude, longitude)
    begin
      # Check if OpenWeatherMap API key is configured
      # If not available, return mock data for demonstration purposes
      api_key = Rails.application.credentials.openweather_api_key
      
      if api_key.blank?
        # Return mock data for demo purposes when API key is not available
        Rails.logger.warn "OpenWeather API key not configured, returning mock data for demo"
        return create_mock_weather_data(latitude, longitude)
      end
      
      # Configure Faraday HTTP client for API requests
      # Faraday provides robust HTTP client functionality with retry and JSON handling
      conn = Faraday.new("https://api.openweathermap.org") do |f|
        f.request :json # Automatically encode request bodies as JSON and set Content-Type header
        f.request :retry # Automatically retry transient failures (network issues, timeouts)
        f.response :json # Automatically decode response bodies as JSON
        f.adapter Faraday.default_adapter # Use the default HTTP adapter
      end    
      
      # Make API request to OpenWeatherMap Current Weather API
      # Documentation: https://openweathermap.org/current
      response = conn.get('/data/2.5/weather', {
        appid: api_key,        # API key for authentication
        lat: latitude,         # Latitude coordinate
        lon: longitude,        # Longitude coordinate
        units: "metric",       # Use metric units (Celsius, meters, etc.)
      })
      
      # Validate API response
      body = response.body
      raise IOError.new "OpenWeather response body failed" unless body
      
      # Debug logging for troubleshooting API issues
      Rails.logger.info "OpenWeather API Response: #{body.inspect}"
      Rails.logger.info "Response Status: #{response.status}"
      
      # Check for API errors first (OpenWeatherMap returns error codes in the response)
      if body.is_a?(Hash) && body["cod"] && body["cod"] != 200
        error_message = body["message"] || "Unknown API error"
        raise IOError.new "OpenWeather API Error (#{body["cod"]}): #{error_message}"
      end
      
      # Validate response structure to ensure all required data is present
      raise IOError.new "OpenWeather main section is missing. Response: #{body.inspect}" unless body["main"]
      raise IOError.new "OpenWeather temperature is missing" unless body["main"]["temp"]
      raise IOError.new "OpenWeather temperature minimum is missing" unless body["main"]["temp_min"]
      raise IOError.new "OpenWeather temperature maximum is missing" unless body["main"]["temp_max"]
      raise IOError.new "OpenWeather weather section is missing" unless body["weather"]
      raise IOError.new "OpenWeather weather section is empty" if body["weather"].empty?
      raise IOError.new "OpenWeather weather description is missing" unless body["weather"][0]["description"]
      
      # Create weather data object with extracted information
      weather = OpenStruct.new
      weather.temperature = body["main"]["temp"]           # Current temperature in Celsius
      weather.temperature_min = body["main"]["temp_min"]  # Minimum temperature in Celsius
      weather.temperature_max = body["main"]["temp_max"]  # Maximum temperature in Celsius
      weather.humidity = body["main"]["humidity"]          # Humidity percentage
      weather.pressure = body["main"]["pressure"]         # Atmospheric pressure in millibars
      weather.description = body["weather"][0]["description"] # Weather condition description
      weather
      
    rescue Faraday::Error => e
      # Handle network-related errors (timeouts, connection issues, etc.)
      Rails.logger.error "Network error calling OpenWeather API: #{e.message}"
      # Return mock data for demo purposes when network fails
      Rails.logger.warn "Network error, returning mock data for demo"
      return create_mock_weather_data(latitude, longitude)
    rescue => e
      # Handle any other unexpected errors
      Rails.logger.error "Error in WeatherService: #{e.message}"
      raise IOError.new "Weather service error: #{e.message}"
    end
  end
  
  private
  
  # Creates mock weather data for demonstration purposes
  # This ensures the application works even when the weather API is unavailable
  # @param latitude [Float] The latitude coordinate
  # @param longitude [Float] The longitude coordinate
  # @return [OpenStruct] Mock weather data
  def self.create_mock_weather_data(latitude, longitude)
    # Generate mock weather data based on coordinates for demo purposes
    # This creates realistic-looking weather data that varies by location
    weather = OpenStruct.new
    weather.temperature = (20 + (latitude * 0.1).round(1))  # Temperature varies by latitude
    weather.temperature_min = weather.temperature - 5       # Min temp is 5 degrees lower
    weather.temperature_max = weather.temperature + 8       # Max temp is 8 degrees higher
    weather.humidity = 65                                    # Fixed humidity for demo
    weather.pressure = 1013                                  # Standard atmospheric pressure
    weather.description = "Clear sky (Demo Data)"           # Clear indication this is demo data
    weather
  end
    
end
