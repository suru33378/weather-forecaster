module ForecastsHelper
end
