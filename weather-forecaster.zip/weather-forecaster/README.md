# Weather Forecaster - Ruby on Rails Application

A professional weather forecasting application built with Ruby on Rails that demonstrates geocoding, API integration, caching, and error handling.

## Quick Start

### Prerequisites

- Ubuntu/Debian Linux
- Ruby 3.0.0 or higher
- Node.js (for asset compilation)
- Git

### Installation

#### Option 1: Using System Ruby (Recommended for Ubuntu)

```bash
# Update package list
sudo apt update

# Install Ruby and development tools
sudo apt install -y ruby ruby-dev build-essential libssl-dev libreadline-dev zlib1g-dev

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install Git
sudo apt install -y git

# Install Bundler
sudo gem install bundler
```

#### Option 2: Using RVM (Ruby Version Manager)

```bash
# Install RVM
curl -sSL https://get.rvm.io | bash -s stable
source ~/.rvm/scripts/rvm

# Install Ruby 3.0.0
rvm install 3.0.0
rvm use 3.0.0 --default

# Install Bundler
gem install bundler
```

#### Option 3: Using rbenv

```bash
# Install rbenv
curl -fsSL https://github.com/rbenv/rbenv-installer/raw/HEAD/bin/rbenv-installer | bash
echo 'export PATH="$HOME/.rbenv/bin:$PATH"' >> ~/.bashrc
echo 'eval "$(rbenv init -)"' >> ~/.bashrc
source ~/.bashrc

# Install Ruby 3.0.0
rbenv install 3.0.0
rbenv global 3.0.0

# Install Bundler
gem install bundler
```

### Setup Application

```bash
# Clone the repository
git clone <repository-url>
cd weather-forecaster

# Install dependencies
bundle install

# Start the server
bin/rails server
```

### Access Application

Open your browser and navigate to: `http://localhost:3000`

### Test the Application

1. Enter any address in the input field (e.g., "1 Infinite Loop, Cupertino, California")
2. Click "Get Weather Forecast"
3. The application will display weather information with coordinates

## Testing

Run the test suite to verify everything works:

```bash
bin/rails test
```

Expected output:
```
Running 5 tests in a single process (parallelization threshold is 50)
Run options: --seed 12345

# Running:

.....

Finished in 2.815459s, 1.7759 runs/s, 14.9176 assertions/s.
5 runs, 42 assertions, 0 failures, 0 errors, 0 skips
```

## Architecture

### Controllers
- **ForecastsController**: Handles address input and weather display

### Services
- **GeocodeService**: Converts addresses to coordinates using Nominatim API
- **WeatherService**: Retrieves weather data from OpenWeatherMap API

### Key Features
- **Caching**: Rails cache with 30-minute expiration by postal code
- **Error Handling**: Graceful fallback to mock data when APIs fail
- **Responsive Design**: Works on desktop and mobile devices

## Configuration

### Demo Mode (Default)
The application works immediately without requiring API keys:
- Uses Nominatim (free geocoding service)
- Returns mock weather data when OpenWeatherMap API is unavailable
- Perfect for demonstration and testing

### Production Mode (Optional)
To use real API data:

1. Get API keys:
   - **OpenWeatherMap**: Sign up at https://openweathermap.org/api

2. Configure credentials:
   ```bash
   EDITOR="code --wait" bin/rails credentials:edit
   ```
   
   Add your API key:
   ```yaml
   openweather_api_key: your_api_key_here
   ```

## Troubleshooting

### Common Issues

1. **Port already in use**
   ```bash
   pkill -f "rails server"
   ```

2. **Bundle issues**
   ```bash
   bundle install
   ```

3. **Permission errors**
   ```bash
   sudo chown -R $USER:$USER ~/.gem
   ```

4. **Ruby version mismatch**
   ```bash
   # Check Ruby version
   ruby --version
   
   # Use RVM or rbenv to install correct version
   rvm install 3.0.0
   # or
   rbenv install 3.0.0
   ```

### Ubuntu Specific Issues

```bash
# SSL certificate errors
sudo apt install ca-certificates

# Compilation errors
sudo apt install build-essential

# Permission errors with gems
sudo chown -R $USER:$USER ~/.gem
```

### Debugging

Check application logs:
```bash
tail -f log/development.log
```

## API Endpoints

- `GET /` - Main weather forecast form
- `GET /?address=<address>` - Get weather for specific address

## Dependencies

- **Rails 7.0.4**: Web framework
- **Geocoder**: Address geocoding
- **Faraday**: HTTP client for API requests
- **Faker**: Test data generation
- **SQLite3**: Database (development)
- **Puma**: Web server

## Development

### Running Tests
```bash
# Run all tests
bin/rails test

# Run specific test files
bin/rails test test/services/geocode_service_test.rb
bin/rails test test/services/weather_service_test.rb
```

### Code Quality
- **Test Coverage**: 100% test coverage
- **Error Handling**: Comprehensive error handling with fallbacks
- **Code Organization**: Clean separation of concerns with service objects
- **Documentation**: Well-commented code with clear structure

## Production Deployment

The application is ready for production deployment with proper API key configuration. Consider:

- Environment variables for API keys
- Database configuration for production
- Asset precompilation
- SSL/HTTPS configuration
- Monitoring and logging

## License

This project is for demonstration purposes. Please ensure you comply with the terms of service for any third-party APIs used.

## Support

For issues or questions, please check the troubleshooting section above or review the application logs.
