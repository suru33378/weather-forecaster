require 'test_helper'

class WeatherServiceTest < ActiveSupport::TestCase

  test "call with known parameters returns valid weather data" do
    # Example coordinates for Cupertino, California
    latitude = 37.331669
    longitude = -122.030098 
    
    # Since we're using demo configuration without API keys,
    # we'll test that the service returns mock data gracefully
    weather = WeatherService.call(latitude, longitude)
    
    # Verify the structure of returned data
    assert weather.temperature.is_a?(Numeric)
    assert weather.temperature_min.is_a?(Numeric)
    assert weather.temperature_max.is_a?(Numeric)
    assert weather.humidity.is_a?(Numeric)
    assert weather.pressure.is_a?(Numeric)
    assert weather.description.is_a?(String)
    refute_empty weather.description
    
    # Verify reasonable ranges (including mock data ranges)
    assert_includes -10..50, weather.temperature
    assert_includes -10..50, weather.temperature_min
    assert_includes -10..50, weather.temperature_max
    assert_includes 0..100, weather.humidity
    assert_includes 800..1200, weather.pressure
  end

  test "call with invalid coordinates returns mock data" do
    # Test with invalid coordinates
    latitude = 999.999
    longitude = 999.999
    
    # Should return mock data for demo purposes
    weather = WeatherService.call(latitude, longitude)
    assert weather.temperature.is_a?(Numeric)
    assert weather.temperature_min.is_a?(Numeric)
    assert weather.temperature_max.is_a?(Numeric)
    assert weather.humidity.is_a?(Numeric)
    assert weather.pressure.is_a?(Numeric)
    assert weather.description.is_a?(String)
    refute_empty weather.description
  end

end
