require 'test_helper'

class GeocodeServiceTest < ActiveSupport::TestCase

  test "call with known address returns valid geocode data" do
    address = "1 Infinite Loop, Cupertino, California"
    
    # The service should either succeed with real data or return mock data
    geocode = GeocodeService.call(address)
    
    # Verify the structure
    assert geocode.latitude.is_a?(Float)
    assert geocode.longitude.is_a?(Float)
    assert geocode.country_code.is_a?(String)
    assert geocode.postal_code.is_a?(String)
    assert geocode.address.is_a?(String)
    
    # Verify coordinates are reasonable
    assert geocode.latitude.between?(-90, 90)
    assert geocode.longitude.between?(-180, 180)
  end

  test "call with invalid address returns mock data" do
    address = "invalid_address_xyz_123"
    
    # Should return mock data for demo purposes
    geocode = GeocodeService.call(address)
    assert geocode.latitude.is_a?(Float)
    assert geocode.longitude.is_a?(Float)
    assert geocode.country_code.is_a?(String)
    assert geocode.postal_code.is_a?(String)
    assert geocode.address.is_a?(String)
    
    # Verify coordinates are reasonable
    assert geocode.latitude.between?(-90, 90)
    assert geocode.longitude.between?(-180, 180)
  end

end
