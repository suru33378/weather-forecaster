# Geocoder configuration for the Weather Forecaster application
# This configuration sets up the geocoding service to work without requiring API keys
# for demonstration purposes while still providing real geocoding functionality

# Configure Geocoder for demo purposes
# This configuration allows the app to work without requiring API keys
Geocoder.configure(
  # Use Nominatim (OpenStreetMap) as the default provider - free and no API key required
  # Nominatim is a free geocoding service that provides good results for most addresses
  # Documentation: https://nominatim.org/release-docs/develop/api/Overview/
  lookup: :nominatim,
  
  # Set timeout for API calls to prevent hanging requests
  # 15 seconds should be sufficient for most geocoding requests
  timeout: 15,
  
  # Use metric units for distance calculations
  # This ensures consistency with the weather data (which uses metric units)
  units: :km,
  
  # Cache results for 1 hour to reduce API calls and improve performance
  # Geocoding results don't change frequently, so caching is safe and beneficial
  cache: Rails.cache,
  cache_prefix: "geocoder:",
  
  # Add user agent for Nominatim (required by their terms of service)
  # This identifies our application to the Nominatim service
  http_headers: {
    "User-Agent" => "WeatherForecaster Demo App"
  }
)

